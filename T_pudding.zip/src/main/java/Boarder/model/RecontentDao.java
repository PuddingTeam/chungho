package Boarder.model;

public class RecontentDao {

}
